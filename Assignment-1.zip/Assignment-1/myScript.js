
//Ans no - 1......

var firstName = "Javascript", lastName = "Learner", age = 25;

console.log(firstName, lastName, age)


//Ans no - 2......

var num1 = 20, num2 = 10;

var sum = num1 + num2;
var subt = num1 - num2;
var multy = num1 * num2;
var div = num1 / num2;

console.log(sum);
console.log(subt);
console.log(multy);
console.log(div);
console.log(div);

var sum2 = 100;
sum2 += 100;

console.log(sum2)


//Ans no - 3...........

var length = 16 ; //It is a number data-type...
console.log(typeof(length));

var Name = "Admin"; //It is an string data-type...
console.log(typeof(Name));

var x = {
 firstName: "Javascript",
 lastName: "Group"
}; // It is an object data-type...

console.log(typeof(x));